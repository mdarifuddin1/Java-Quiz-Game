
package quiz_game;



public class main {
    
    public static void main(String[] args) {
        
        Quiz quiz = new Quiz();
        
    }
    
}
